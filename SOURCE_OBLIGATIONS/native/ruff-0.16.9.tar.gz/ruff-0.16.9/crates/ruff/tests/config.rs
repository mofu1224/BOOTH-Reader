//! Tests for the `ruff config` subcommand.
use std::process::Command;

use insta_cmd::{assert_cmd_snapshot, get_cargo_bin};

const BIN_NAME: &str = "ruff";

#[test]
fn lint_select() {
    assert_cmd_snapshot!(
        Command::new(get_cargo_bin(BIN_NAME)).arg("config").arg("lint.select"), @r#"
    success: true
    exit_code: 0
    ----- stdout -----
    A list of rule codes or prefixes to enable. Prefixes can specify exact
    rules (like `F841`), entire groups (like `F`), or anything in
    between.

    When breaking ties between enabled and disabled rules (via `select` and
    `ignore`, respectively), more specific prefixes override less
    specific prefixes. `ignore` takes precedence over `select` if the
    same prefix appears in both.

    In preview, categories like `correctness` and `suspicious` can be used
    in addition to rule codes and linter group prefixes.

    Default value: See https://docs.astral.sh/ruff/default-rules/ or run `ruff check --show-settings --isolated`
    Type: list[RuleSelector]
    Example usage:
    ```toml
    # On top of the defaults, enable flake8-bugbear (`B`) and flake8-quotes (`Q`).
    extend-select = ["B", "Q"]
    ```

    ----- stderr -----
    "#
    );
}

#[test]
fn lint_select_json() {
    assert_cmd_snapshot!(
        Command::new(get_cargo_bin(BIN_NAME)).arg("config").arg("lint.select").arg("--output-format").arg("json"), @r##"
    success: true
    exit_code: 0
    ----- stdout -----
    {
      "doc": "A list of rule codes or prefixes to enable. Prefixes can specify exact\nrules (like `F841`), entire groups (like `F`), or anything in\nbetween.\n\nWhen breaking ties between enabled and disabled rules (via `select` and\n`ignore`, respectively), more specific prefixes override less\nspecific prefixes. `ignore` takes precedence over `select` if the\nsame prefix appears in both.\n\nIn preview, categories like `correctness` and `suspicious` can be used\nin addition to rule codes and linter group prefixes.",
      "default": "See https://docs.astral.sh/ruff/default-rules/ or run `ruff check --show-settings --isolated`",
      "value_type": "list[RuleSelector]",
      "scope": null,
      "example": "# On top of the defaults, enable flake8-bugbear (`B`) and flake8-quotes (`Q`).\nextend-select = [\"B\", \"Q\"]",
      "deprecated": null
    }

    ----- stderr -----
    "##
    );
}
