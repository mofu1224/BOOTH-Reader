<!-- This file is generated. DO NOT EDIT -->

# ruff_macros

This crate is an internal component of [Ruff](https://crates.io/crates/ruff). The Rust API exposed
here is unstable and will have frequent breaking changes.

This version (0.0.9) is a component of [Ruff 0.16.3](https://crates.io/crates/ruff/0.16.3). The
source can be found [here](https://github.com/astral-sh/ruff/blob/0.16.3/crates/ruff_macros).

See Ruff's [crate versioning policy](https://docs.astral.sh/ruff/versioning/#crate-versioning) for
details on versioning.
