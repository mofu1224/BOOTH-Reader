def _():
    nonlocal x
