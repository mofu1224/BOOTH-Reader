# Copyright (c) Microsoft Corporation.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio

import pytest

from playwright.async_api import Browser, Page, ScreencastFrame, ScreencastSize
from tests.server import Server


async def ensure_some_frames(page: Page) -> None:
    for _ in range(100):
        await page.evaluate(
            "() => new Promise(f => requestAnimationFrame(() => requestAnimationFrame(f)))"
        )
    await page.screenshot()


async def test_should_expose_screencast_property(page: Page) -> None:
    assert page.screencast is page.screencast


async def test_start_should_deliver_frames_via_callback(
    page: Page, server: Server
) -> None:
    received: list = []
    event = asyncio.Event()

    def on_frame(frame: ScreencastFrame) -> None:
        received.append(frame["data"])
        event.set()

    await page.screencast.start(on_frame=on_frame)
    await page.goto(server.EMPTY_PAGE)
    await page.evaluate("() => document.body.style.backgroundColor = 'red'")
    # Force a couple of paint cycles so engines that only emit on visual change
    # still produce a frame. Mirrors upstream `ensureSomeFrames`.
    for _ in range(3):
        await page.evaluate(
            "() => new Promise(f => requestAnimationFrame(() => requestAnimationFrame(f)))"
        )
    await page.screenshot()
    await asyncio.wait_for(event.wait(), timeout=10)
    await page.screencast.stop()
    assert len(received) >= 1
    assert all(isinstance(d, bytes) and len(d) > 0 for d in received)


async def test_should_acknowledge_frames_after_async_callback(
    page: Page, server: Server
) -> None:
    first_frame = asyncio.Event()
    release_callback = asyncio.Event()
    frame_count = 0
    last_frame_timestamp = 0.0

    async def on_frame(_: ScreencastFrame) -> None:
        nonlocal frame_count, last_frame_timestamp
        frame_count += 1
        last_frame_timestamp = asyncio.get_running_loop().time()
        first_frame.set()
        await release_callback.wait()

    await page.screencast.start(on_frame=on_frame)
    try:
        await page.goto(server.EMPTY_PAGE)
        await page.evaluate(
            """() => {
                const animate = () => {
                    document.body.style.backgroundColor =
                        document.body.style.backgroundColor === "red" ? "blue" : "red";
                    requestAnimationFrame(animate);
                };
                requestAnimationFrame(animate);
            }"""
        )
        await asyncio.wait_for(first_frame.wait(), timeout=10)
        while asyncio.get_running_loop().time() - last_frame_timestamp <= 1:
            await page.wait_for_timeout(100)

        frames_while_blocked = frame_count
        await ensure_some_frames(page)
        assert frame_count == frames_while_blocked
        release_callback.set()
        for _ in range(10):
            await page.evaluate(
                """() => {
                    document.body.style.backgroundColor =
                        document.body.style.backgroundColor === "red" ? "blue" : "red";
                }"""
            )
            await ensure_some_frames(page)
            if frame_count > frames_while_blocked:
                break
        assert frame_count > frames_while_blocked
    finally:
        release_callback.set()
        await page.screencast.stop()


async def test_should_report_callback_errors_and_continue_delivering_frames(
    page: Page, server: Server
) -> None:
    await page.goto(server.EMPTY_PAGE)
    await page.evaluate(
        """() => {
            const animate = () => {
                document.body.style.backgroundColor =
                    document.body.style.backgroundColor === "red" ? "blue" : "red";
                requestAnimationFrame(animate);
            };
            requestAnimationFrame(animate);
        }"""
    )
    callback_count = 0

    async def on_frame(_: ScreencastFrame) -> None:
        nonlocal callback_count
        callback_count += 1
        raise RuntimeError("screencast callback failed")

    await page.screencast.start(on_frame=on_frame)
    try:
        callback_error = None
        for _ in range(100):
            try:
                await page.wait_for_timeout(100)
            except RuntimeError as error:
                callback_error = error
            if callback_error and callback_count > 1:
                break
        assert callback_error
        assert "screencast callback failed" in str(callback_error)
        assert callback_count > 1
    finally:
        try:
            await page.screencast.stop()
        except RuntimeError as error:
            assert "screencast callback failed" in str(error)
            await page.screencast.stop()


async def test_starting_twice_should_throw(page: Page) -> None:
    await page.screencast.start(on_frame=lambda f: None)
    try:
        with pytest.raises(Exception, match="already started"):
            await page.screencast.start(on_frame=lambda f: None)
    finally:
        await page.screencast.stop()


async def test_show_overlays_and_overlay_apis_should_not_throw(page: Page) -> None:
    await page.screencast.start(on_frame=lambda f: None)
    try:
        await page.screencast.show_overlay("<div>hello</div>", duration=100)
        await page.screencast.show_chapter("ch", description="desc", duration=100)
        await page.screencast.hide_overlays()
        await page.screencast.show_overlays()
        await page.screencast.show_actions(duration=100, position="top-right")
        await page.screencast.hide_actions()
    finally:
        await page.screencast.stop()


async def test_on_frame_receives_viewport_size(
    browser: Browser, server: Server
) -> None:
    context = await browser.new_context(viewport={"width": 1000, "height": 400})
    async with context:
        page = await context.new_page()
        received: list = []

        def on_frame(frame: ScreencastFrame) -> None:
            received.append(frame)

        size: ScreencastSize = {"width": 500, "height": 400}
        await page.screencast.start(on_frame=on_frame, size=size)
        await page.goto(server.EMPTY_PAGE)
        await page.evaluate("() => document.body.style.backgroundColor = 'red'")
        for _ in range(100):
            await page.evaluate(
                "() => new Promise(f => requestAnimationFrame(() => requestAnimationFrame(f)))"
            )
        await page.screenshot()
        await page.screencast.stop()
        assert len(received) >= 1
        assert any(frame["viewportWidth"] == 1000 for frame in received)
        for frame in received:
            assert frame["viewportHeight"] == 400
            assert isinstance(frame["timestamp"], (int, float))


async def test_show_actions_should_accept_cursor_param(page: Page) -> None:
    await page.screencast.start(on_frame=lambda f: None)
    try:
        async with await page.screencast.show_actions(duration=100, cursor="pointer"):
            pass
        async with await page.screencast.show_actions(duration=100, cursor="none"):
            pass
    finally:
        await page.screencast.stop()
