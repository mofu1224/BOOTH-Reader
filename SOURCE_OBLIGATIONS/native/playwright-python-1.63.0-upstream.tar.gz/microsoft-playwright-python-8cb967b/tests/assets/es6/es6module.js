export default 42;
